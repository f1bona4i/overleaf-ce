The patches in this folder are applied by `patch-package` to dependencies, particularly those which need changes that are difficult to apply upstream.
